import { describe, expect, it } from 'vitest';
import { accelerations, stepVelocityVerlet, totalMomentum } from '../src/physics/nbody';
import { vec3 } from '../src/math/vector3';
import type { Body } from '../src/physics/types';

const pair: Body[] = [
 {id:'a',mass:2,radius:1,position:vec3(-1,0,0),velocity:vec3(0,0,0),color:'#fff'},
 {id:'b',mass:1,radius:.5,position:vec3(1,0,0),velocity:vec3(0,0,0),color:'#fff'}
];
describe('N-body physics core', () => {
 it('accelerates two bodies toward each other', () => {
  const a=accelerations(pair,{gravitationalConstant:1,softening:.1});
  expect(a[0]!.x).toBeGreaterThan(0); expect(a[1]!.x).toBeLessThan(0);
 });
 it('preserves zero net momentum for an isolated system to numerical tolerance', () => {
  const initial=[{...pair[0]!,velocity:vec3(0,0.5,0)},{...pair[1]!,velocity:vec3(0,-1,0)}];
  const before=totalMomentum(initial); const after=totalMomentum(stepVelocityVerlet(initial,.001));
  expect(after.x).toBeCloseTo(before.x,10); expect(after.y).toBeCloseTo(before.y,10); expect(after.z).toBeCloseTo(before.z,10);
 });
 it('rejects non-positive time steps', () => expect(() => stepVelocityVerlet(pair,0)).toThrow(/positive/));
 it('rejects duplicate body ids', () => expect(() => accelerations([pair[0]!,{...pair[1]!,id:'a'}])).toThrow(/unique/));
});
