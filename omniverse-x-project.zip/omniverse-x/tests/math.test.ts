import { describe, expect, it } from 'vitest';
import { determinant2, multiply, solveLinearSystem, transpose } from '../src/math/linearAlgebra';

describe('linear algebra', () => {
  it('transposes a rectangular matrix', () => expect(transpose([[1,2,3],[4,5,6]])).toEqual([[1,4],[2,5],[3,6]]));
  it('multiplies compatible matrices', () => expect(multiply([[1,2],[3,4]], [[5],[6]])).toEqual([[17],[39]]));
  it('computes a 2x2 determinant', () => expect(determinant2([[3,2],[1,4]])).toBe(10));
  it('solves a linear system using pivoting', () => {
    const [x,y] = solveLinearSystem([[2,1],[1,-1]],[5,1]);
    expect(x).toBeCloseTo(2); expect(y).toBeCloseTo(1);
  });
  it('rejects singular systems', () => expect(() => solveLinearSystem([[1,2],[2,4]],[3,6])).toThrow(/singular/));
});
