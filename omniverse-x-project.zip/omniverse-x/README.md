# OMNIVERSE X

A modular, browser-based scientific playground combining numerical mathematics, Newtonian N-body simulation, and interactive Three.js visualization. This repository is a runnable research-oriented **starter system**, not a claim to be a validated scientific simulator for real astronomical predictions.

## Features

- **3D scene:** interactive perspective presets, body meshes, orbit trails, deterministic star field, responsive renderer cleanup.
- **Physics core:** softened Newtonian pairwise gravity, positive-mass validation, velocity-Verlet integration, total energy and momentum diagnostics.
- **Math core:** vector operations, matrix transpose/multiplication, 2×2 determinant, Gaussian elimination with partial pivoting.
- **Workbench:** live controls for gravity, simulation speed, trails, determinant calculation, and a 2×2 linear solver.
- **Quality gates:** Vitest unit tests, strict TypeScript checks, GitHub Actions build-and-deploy workflow.

## Requirements

- Node.js 20 or later
- npm
- A modern browser with WebGL support

## Local development

```bash
npm install
npm run dev
```

Vite prints a local URL (normally `http://localhost:5173`). The 3D renderer requires WebGL. The app uses Google Fonts as an optional visual enhancement; if fonts cannot load, local system fallbacks are used.

## Tests and production build

```bash
npm test
npm run typecheck
npm run build
npm run preview
```

`npm test` checks core linear algebra and physics invariants. `npm run build` creates the static website in `dist/`.

## Deploy to GitHub Pages

1. Create a GitHub repository named **`omniverse-x`** and push this project's files to its `main` branch.
2. Keep `.github/workflows/deploy.yml` in the repository.
3. In GitHub, open **Settings → Pages** and set the publishing source to **GitHub Actions**.
4. Push to `main` or run the workflow manually in **Actions**. The workflow installs dependencies, runs tests and type checks, builds the app, and deploys `dist/`.
5. The Vite `base` setting uses `/omniverse-x/` for GitHub Actions. If you choose a repository with a different name, update that base path in `vite.config.ts` to match the repository name.

> Use Run `npm install` once locally and commit the generated `package-lock.json` for reproducible dependency installs. The workflow currently uses `npm install` so the first deployment also works before a lock file has been generated.

## Numerical model and limitations

- The integrator is **velocity-Verlet**, with fixed simulation step `dt = 0.008` in the UI and an accumulator to reduce frame-rate dependence.
- Gravity uses a Plummer-style softening parameter `ε`: the force denominator uses `(r² + ε²)^(3/2)` to avoid singular acceleration at coincident positions.
- Pairwise force evaluation is O(N²), appropriate for this small demonstration. For large systems, consider a Barnes–Hut tree or GPU acceleration and validate errors against reference cases.
- The initial system uses arbitrary, dimensionless parameters and is not a real solar-system ephemeris. Energy conservation is approximate and depends on time step and numerical setup.
- The current renderer has camera presets, not full orbit-control dragging. Body collision, relativistic corrections, adaptive stepping, uncertainty estimates, and persisted experiment sessions are not implemented yet.
- The project has no backend or API keys; all computations run in the browser.

## Project layout

```text
omniverse-x/
├── .github/workflows/deploy.yml
├── index.html
├── package.json
├── tsconfig.json
├── vite.config.ts
├── README.md
├── src/
│   ├── main.ts
│   ├── math/
│   │   ├── vector3.ts
│   │   └── linearAlgebra.ts
│   ├── physics/
│   │   ├── types.ts
│   │   ├── nbody.ts
│   │   └── simulation.ts
│   ├── visualization/scene.ts
│   └── ui/styles.css
└── tests/
    ├── math.test.ts
    └── physics.test.ts
```

## License

MIT. Third-party dependencies retain their respective licenses.
