import './ui/styles.css';
import { NBodySimulation } from './physics/simulation';
import { createSolarToySystem } from './physics/nbody';
import { UniverseScene } from './visualization/scene';
import { determinant2, solveLinearSystem } from './math/linearAlgebra';

const app = document.querySelector<HTMLDivElement>('#app');
if (!app) throw new Error('Missing #app root');
app.innerHTML = `
<div class="app-shell">
 <header class="topbar"><a class="brand" href="#top" style="color:inherit">OMNIVERSE <span>X</span> ✦</a><div class="top-meta">SCIENTIFIC COMPUTING / BUILD 0.1.0</div><span class="badge">LOCAL SIMULATION ONLINE</span></header>
 <section class="hero" id="top"><div><div class="eyebrow">MULTI-DOMAIN SCIENTIFIC PLAYGROUND</div><h1>Explore the <span class="gradient">laws of motion.</span></h1><p>一個開源的數學、物理與 3D 實驗工作台。調整重力參數、觀察多體系統、檢視能量與動量，並在同一個介面測試線性代數運算。</p></div><span class="status">● ENGINE READY</span></section>
 <div class="layout">
  <section class="panel"><div class="panel-head"><div><div class="kicker">01 / GRAVITATIONAL LAB</div><h2>多體重力模擬器</h2></div><span class="badge" id="simState">PAUSED</span></div>
   <div class="scene-host" id="sceneHost"><div class="scene-overlay"><span class="overlay-chip" id="timeChip">t = 0.00</span><span class="overlay-chip">VELOCITY-VERLET · SOFTENED NEWTONIAN GRAVITY</span></div></div>
   <div class="scene-footer"><div class="controls"><button class="btn primary" id="playBtn">▶ 開始</button><button class="btn" id="stepBtn">單步推進</button><button class="btn" id="resetBtn">重設</button></div><div class="controls"><button class="btn active" data-camera="orbit">軌道視角</button><button class="btn" data-camera="top">俯視</button><button class="btn" data-camera="side">側視</button></div></div>
  </section>
  <aside class="side">
   <section class="panel"><div class="panel-head"><div><div class="kicker">02 / SYSTEM DIAGNOSTICS</div><h2>物理狀態</h2></div><span class="badge">LIVE</span></div><div class="metrics"><div class="metric"><label>模擬時間</label><strong id="timeMetric">0.00</strong><small>simulation units</small></div><div class="metric"><label>總能量</label><strong id="energyMetric">—</strong><small>kinetic + potential</small></div><div class="metric"><label>總動量大小</label><strong id="momentumMetric">—</strong><small>momentum norm</small></div><div class="metric"><label>天體數量</label><strong id="bodyMetric">4</strong><small>interacting bodies</small></div></div></section>
   <section class="panel"><div class="panel-head"><div><div class="kicker">03 / PARAMETERS</div><h2>模擬控制</h2></div></div><div class="control-body"><div class="control-row"><label for="gravity">重力常數 G</label><output id="gravityOut">1.00</output></div><input id="gravity" type="range" min="0.1" max="2.5" step="0.05" value="1"><div class="control-row"><label for="speed">模擬速度</label><output id="speedOut">1.0×</output></div><input id="speed" type="range" min="0.25" max="3" step="0.25" value="1"><div class="control-row"><label for="trails">顯示軌跡</label><input id="trails" type="checkbox" checked></div><p style="color:var(--muted);font-size:11px;margin-bottom:0">重力參數會影響下一個積分步驟。這是教學用無量綱模型，並非精確天文星曆。</p></div></section>
   <section class="panel"><div class="panel-head"><div><div class="kicker">04 / CELESTIAL BODIES</div><h2>系統成員</h2></div></div><div class="control-body"><div class="body-list" id="bodyList"></div></div></section>
  </aside>
 </div>
 <div class="section-title"><div><div class="eyebrow">MATH TOOLKIT</div><h2>數學核心模組</h2><p>可測試的數學工具，不是靜態裝飾。</p></div></div>
 <div class="cards"><article class="panel feature"><div class="num">MATH / 01</div><h3>三維向量運算</h3><p>向量加減、純量乘法、內積、長度與距離。作為物理引擎的基礎。</p><div class="equation">r⃗ = (x, y, z)</div></article><article class="panel feature"><div class="num">MATH / 02</div><h3>線性方程組</h3><p>使用部分主元選取的高斯消去法求解線性系統，對奇異矩陣會明確回報錯誤。</p><div class="equation">A x = b</div></article><article class="panel feature"><div class="num">PHYSICS / 03</div><h3>速度 Verlet 積分</h3><p>二階數值積分方法，適用於平滑力場中的經典力學教學模擬。</p><div class="equation">xₙ₊₁ = xₙ + vₙΔt + ½aₙΔt²</div></article></div>
 <div class="section-title"><div><div class="eyebrow">COMPUTATION WORKBENCH</div><h2>可執行的數學實驗</h2><p>輸入數值，直接呼叫計算核心並查看結果。</p></div></div>
 <div class="lab-grid"><section class="panel lab"><h3>2 × 2 矩陣行列式</h3><p>計算矩陣 [[a,b],[c,d]] 的 ad − bc。</p><div class="controls"><input id="ma" type="number" value="3" aria-label="矩陣 a" style="width:65px"><input id="mb" type="number" value="2" aria-label="矩陣 b" style="width:65px"><input id="mc" type="number" value="1" aria-label="矩陣 c" style="width:65px"><input id="md" type="number" value="4" aria-label="矩陣 d" style="width:65px"></div><button class="btn primary" id="detBtn" style="margin:12px 0">計算行列式</button><div class="output" id="detOut" aria-live="polite">等待計算…</div></section>
 <section class="panel lab"><h3>線性方程組求解器</h3><p>解 2x + y = 5 與 x − y = 1，可修改右側常數。</p><div class="controls"><input id="rhs1" type="number" value="5" aria-label="第一個方程右側常數" style="width:90px"><input id="rhs2" type="number" value="1" aria-label="第二個方程右側常數" style="width:90px"></div><button class="btn primary" id="solveBtn" style="margin:12px 0">求解系統</button><div class="output" id="solveOut" aria-live="polite">等待計算…</div></section></div>
 <footer class="footer"><span>OMNIVERSE X · OPEN SCIENCE, REPRODUCIBLE COMPUTATION</span><span>TypeScript · Three.js · Vite · Vitest</span><span>研究級方向的可執行起始版本 v0.1.0</span></footer>
</div>`;

const sim = new NBodySimulation();
const scene = new UniverseScene(document.querySelector<HTMLElement>('#sceneHost')!, createSolarToySystem());
let speed = 1;
let last = performance.now();
let accumulator = 0;
let lastUi = 0;
const fixedDt = 0.008;

function updateUI(): void {
 const s = sim.current();
 const momentum = Math.hypot(s.totalMomentum.x,s.totalMomentum.y,s.totalMomentum.z);
 document.querySelector('#timeMetric')!.textContent = s.time.toFixed(2);
 document.querySelector('#timeChip')!.textContent = `t = ${s.time.toFixed(2)}`;
 document.querySelector('#energyMetric')!.textContent = s.totalEnergy.toFixed(3);
 document.querySelector('#momentumMetric')!.textContent = momentum.toExponential(2);
 document.querySelector('#bodyMetric')!.textContent = String(s.bodies.length);
 document.querySelector('#simState')!.textContent = sim.isRunning ? 'RUNNING' : 'PAUSED';
 document.querySelector('#playBtn')!.textContent = sim.isRunning ? 'Ⅱ 暫停' : '▶ 開始';
 document.querySelector('#bodyList')!.innerHTML = s.bodies.map(b=>`<div class="body-row"><span class="dot" style="background:${b.color}"></span><div><strong>${b.id}</strong><small>mass ${b.mass} · speed ${Math.hypot(b.velocity.x,b.velocity.y,b.velocity.z).toFixed(2)}</small></div></div>`).join('');
 scene.update(s,(document.querySelector<HTMLInputElement>('#trails')!).checked);
}
function animate(now: number): void {
 if (!document.body.contains(scene.renderer.domElement)) return;
 const realDt = Math.min((now-last)/1000,0.05); last = now;
 if (sim.isRunning) {
  accumulator += realDt * speed;
  let steps = 0;
  while (accumulator >= fixedDt && steps < 20) { sim.tick(fixedDt); accumulator -= fixedDt; steps++; }
  if (now-lastUi > 100) { updateUI(); lastUi = now; }
 }
 requestAnimationFrame(animate);
}
requestAnimationFrame(animate);
updateUI();

document.querySelector<HTMLButtonElement>('#playBtn')!.addEventListener('click',()=>{sim.isRunning?sim.pause():sim.play();updateUI();});
document.querySelector<HTMLButtonElement>('#stepBtn')!.addEventListener('click',()=>{sim.pause();sim.tick(fixedDt);updateUI();});
document.querySelector<HTMLButtonElement>('#resetBtn')!.addEventListener('click',()=>{sim.reset();accumulator=0;updateUI();});
document.querySelector<HTMLInputElement>('#gravity')!.addEventListener('input',e=>{const v=Number((e.target as HTMLInputElement).value);sim.setGravity(v);document.querySelector('#gravityOut')!.textContent=v.toFixed(2);});
document.querySelector<HTMLInputElement>('#speed')!.addEventListener('input',e=>{speed=Number((e.target as HTMLInputElement).value);document.querySelector('#speedOut')!.textContent=`${speed.toFixed(2)}×`;});
document.querySelector<HTMLInputElement>('#trails')!.addEventListener('change',updateUI);
document.querySelectorAll<HTMLButtonElement>('[data-camera]').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('[data-camera]').forEach(b=>b.classList.remove('active'));btn.classList.add('active');scene.setCameraPreset(btn.dataset.camera as 'orbit'|'top'|'side');}));
document.querySelector<HTMLButtonElement>('#detBtn')!.addEventListener('click',()=>{
 try { const a=['ma','mb','mc','md'].map(id=>Number((document.querySelector<HTMLInputElement>(`#${id}`)!).value));if(!a.every(Number.isFinite))throw new Error('請輸入有效數字');const result=determinant2([[a[0]!,a[1]!],[a[2]!,a[3]!]]);document.querySelector('#detOut')!.textContent=`det(A) = ad − bc\n= ${a[0]} × ${a[3]} − ${a[1]} × ${a[2]}\n= ${result}`; } catch(err) { document.querySelector('#detOut')!.textContent=err instanceof Error?err.message:'未知錯誤'; }
});
document.querySelector<HTMLButtonElement>('#solveBtn')!.addEventListener('click',()=>{
 try { const b1=Number((document.querySelector<HTMLInputElement>('#rhs1')!).value),b2=Number((document.querySelector<HTMLInputElement>('#rhs2')!).value);if(!Number.isFinite(b1)||!Number.isFinite(b2))throw new Error('請輸入有效數字');const [x,y]=solveLinearSystem([[2,1],[1,-1]],[b1,b2]);document.querySelector('#solveOut')!.textContent=`x = ${x!.toFixed(6)}\ny = ${y!.toFixed(6)}\n殘差：${(2*x!+y!-b1).toExponential(2)}, ${(x!-y!-b2).toExponential(2)}`; } catch(err) { document.querySelector('#solveOut')!.textContent=err instanceof Error?err.message:'未知錯誤'; }
});
window.addEventListener('beforeunload',()=>scene.dispose(),{once:true});
