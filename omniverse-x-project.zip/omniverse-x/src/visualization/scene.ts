import * as THREE from 'three';
import type { Body, SimulationSnapshot } from '../physics/types';

export class UniverseScene {
  readonly renderer: THREE.WebGLRenderer;
  readonly scene = new THREE.Scene();
  readonly camera: THREE.PerspectiveCamera;
  private root = new THREE.Group();
  private meshes = new Map<string, THREE.Mesh>();
  private trails = new Map<string, THREE.Line>();
  private trailPoints = new Map<string, THREE.Vector3[]>();
  private resizeObserver: ResizeObserver;
  private disposed = false;

  constructor(private readonly host: HTMLElement, initialBodies: Body[]) {
    this.scene.background = new THREE.Color('#080d1b');
    this.scene.fog = new THREE.FogExp2('#080d1b', 0.008);
    this.camera = new THREE.PerspectiveCamera(48, 1, 0.1, 1000);
    this.camera.position.set(22, 25, 38);
    this.camera.lookAt(0, 0, 0);
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.setSize(host.clientWidth || 800, host.clientHeight || 500);
    this.renderer.domElement.className = 'scene-canvas';
    this.renderer.domElement.setAttribute('aria-label', '可互動的 3D 重力系統視覺化');
    host.appendChild(this.renderer.domElement);
    this.scene.add(this.root);
    this.scene.add(new THREE.AmbientLight('#b7c7ff', 1.6));
    const key = new THREE.PointLight('#c4b5fd', 180, 150); key.position.set(0, 0, 0); this.scene.add(key);
    const grid = new THREE.GridHelper(60, 30, '#28405d', '#15243b'); grid.position.y = -4; this.scene.add(grid);
    this.addStars();
    initialBodies.forEach(b => this.addBody(b));
    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(host);
    this.resize();
    this.render();
  }
  private addStars(): void {
    const points: number[] = [];
    let seed = 1837;
    const random = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
    for (let i=0;i<900;i++) points.push((random()-.5)*180,(random()-.5)*100,(random()-.5)*180);
    const geometry = new THREE.BufferGeometry(); geometry.setAttribute('position', new THREE.Float32BufferAttribute(points,3));
    const stars = new THREE.Points(geometry,new THREE.PointsMaterial({color:'#9caed6',size:.12,transparent:true,opacity:.72}));
    this.scene.add(stars);
  }
  private addBody(body: Body): void {
    const geometry = new THREE.SphereGeometry(body.radius, 28, 20);
    const material = new THREE.MeshStandardMaterial({ color: body.color, emissive: body.color, emissiveIntensity: body.id === 'star' ? 1.3 : .25, roughness: .35, metalness: .12 });
    const mesh = new THREE.Mesh(geometry, material); mesh.position.set(body.position.x,body.position.y,body.position.z);
    mesh.userData.bodyId = body.id; this.root.add(mesh); this.meshes.set(body.id,mesh);
    const trailGeometry = new THREE.BufferGeometry(); trailGeometry.setFromPoints([]);
    const line = new THREE.Line(trailGeometry,new THREE.LineBasicMaterial({color:body.color,transparent:true,opacity:.55}));
    this.root.add(line); this.trails.set(body.id,line); this.trailPoints.set(body.id,[]);
  }
  update(snapshot: SimulationSnapshot, showTrails = true): void {
    for (const body of snapshot.bodies) {
      const mesh = this.meshes.get(body.id); if (!mesh) continue;
      mesh.position.set(body.position.x,body.position.y,body.position.z);
      if (body.id === 'star') mesh.rotation.y += .012;
      const points = this.trailPoints.get(body.id)!;
      if (showTrails && snapshot.time > 0) {
        const last = points[points.length-1];
        if (!last || last.distanceTo(mesh.position) > .12) points.push(mesh.position.clone());
        if (points.length > 180) points.shift();
      } else if (!showTrails) points.length = 0;
      const line = this.trails.get(body.id)!;
      line.visible = showTrails && points.length > 1;
      line.geometry.dispose(); line.geometry = new THREE.BufferGeometry().setFromPoints(points);
    }
    this.render();
  }
  setCameraPreset(preset: 'orbit'|'top'|'side'): void {
    if (preset === 'top') this.camera.position.set(0,45,.01);
    else if (preset === 'side') this.camera.position.set(45,3,0);
    else this.camera.position.set(22,25,38);
    this.camera.lookAt(0,0,0); this.render();
  }
  private resize(): void {
    if (this.disposed) return;
    const width = Math.max(1,this.host.clientWidth), height = Math.max(1,this.host.clientHeight);
    this.camera.aspect = width/height; this.camera.updateProjectionMatrix(); this.renderer.setSize(width,height,false); this.render();
  }
  render(): void { if (!this.disposed) this.renderer.render(this.scene,this.camera); }
  dispose(): void {
    this.disposed = true; this.resizeObserver.disconnect();
    this.scene.traverse(obj => { if (obj instanceof THREE.Mesh || obj instanceof THREE.Line || obj instanceof THREE.Points) { obj.geometry.dispose(); const material = obj.material; if (Array.isArray(material)) material.forEach(m=>m.dispose()); else material.dispose(); } });
    this.renderer.dispose(); this.renderer.domElement.remove();
  }
}
