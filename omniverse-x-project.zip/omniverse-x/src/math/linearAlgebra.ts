/** Dense row-major matrix helpers. These routines favor clarity over large-scale performance. */
export type Matrix = number[][];
export function transpose(a: Matrix): Matrix {
  if (!a.length) return [];
  const cols = a[0]!.length;
  if (a.some(row => row.length !== cols)) throw new Error('Matrix must be rectangular');
  return Array.from({ length: cols }, (_, j) => a.map(row => row[j]!));
}
export function multiply(a: Matrix, b: Matrix): Matrix {
  if (!a.length || !b.length) return [];
  const inner = a[0]!.length;
  if (a.some(r => r.length !== inner) || b.some(r => r.length !== b[0]!.length)) throw new Error('Matrices must be rectangular');
  if (inner !== b.length) throw new Error('Incompatible matrix dimensions');
  const bt = transpose(b);
  return a.map(row => bt.map(col => row.reduce((sum, x, i) => sum + x * col[i]!, 0)));
}
export function determinant2(a: Matrix): number {
  if (a.length !== 2 || a.some(r => r.length !== 2)) throw new Error('Expected a 2x2 matrix');
  return a[0]![0]! * a[1]![1]! - a[0]![1]! * a[1]![0]!;
}
export function solveLinearSystem(a: Matrix, b: number[], epsilon = 1e-12): number[] {
  const n = a.length;
  if (n === 0 || b.length !== n || a.some(row => row.length !== n)) throw new Error('Expected a square matrix and matching vector');
  const m = a.map((row, i) => [...row, b[i]!]);
  for (let col = 0; col < n; col++) {
    let pivot = col;
    for (let row = col + 1; row < n; row++) if (Math.abs(m[row]![col]!) > Math.abs(m[pivot]![col]!)) pivot = row;
    if (Math.abs(m[pivot]![col]!) < epsilon) throw new Error('Matrix is singular or ill-conditioned');
    [m[col], m[pivot]] = [m[pivot]!, m[col]!];
    const divisor = m[col]![col]!;
    for (let j = col; j <= n; j++) m[col]![j] = m[col]![j]! / divisor;
    for (let row = 0; row < n; row++) {
      if (row === col) continue;
      const factor = m[row]![col]!;
      for (let j = col; j <= n; j++) m[row]![j] = m[row]![j]! - factor * m[col]![j]!;
    }
  }
  return m.map(row => row[n]!);
}
