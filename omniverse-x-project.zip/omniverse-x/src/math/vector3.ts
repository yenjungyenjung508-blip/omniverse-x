/** Small immutable 3D vector for the physics core. Units are caller-defined. */
export type Vec3 = Readonly<{ x: number; y: number; z: number }>;
export const vec3 = (x = 0, y = 0, z = 0): Vec3 => ({ x, y, z });
export const add = (a: Vec3, b: Vec3): Vec3 => vec3(a.x + b.x, a.y + b.y, a.z + b.z);
export const sub = (a: Vec3, b: Vec3): Vec3 => vec3(a.x - b.x, a.y - b.y, a.z - b.z);
export const scale = (a: Vec3, k: number): Vec3 => vec3(a.x * k, a.y * k, a.z * k);
export const dot = (a: Vec3, b: Vec3): number => a.x * b.x + a.y * b.y + a.z * b.z;
export const normSquared = (a: Vec3): number => dot(a, a);
export const norm = (a: Vec3): number => Math.sqrt(normSquared(a));
export const distance = (a: Vec3, b: Vec3): number => norm(sub(a, b));
export function assertFiniteVec3(v: Vec3, name = 'vector'): void {
  if (![v.x, v.y, v.z].every(Number.isFinite)) throw new Error(`${name} must contain finite numbers`);
}
