import { add, norm, scale, sub, vec3, type Vec3, assertFiniteVec3 } from '../math/vector3';
import type { Body, PhysicsConfig, SimulationSnapshot } from './types';

export const DEFAULT_PHYSICS: PhysicsConfig = { gravitationalConstant: 1, softening: 0.15 };

function validateBodies(bodies: readonly Body[]): void {
  const ids = new Set<string>();
  for (const b of bodies) {
    if (!b.id || ids.has(b.id)) throw new Error('Body IDs must be non-empty and unique');
    ids.add(b.id);
    if (!(b.mass > 0) || !Number.isFinite(b.mass)) throw new Error(`Body ${b.id} mass must be positive and finite`);
    if (!(b.radius > 0) || !Number.isFinite(b.radius)) throw new Error(`Body ${b.id} radius must be positive and finite`);
    assertFiniteVec3(b.position, `${b.id}.position`); assertFiniteVec3(b.velocity, `${b.id}.velocity`);
  }
}

/** Newtonian gravity with Plummer softening to prevent singular accelerations near overlap. */
export function accelerations(bodies: readonly Body[], config: PhysicsConfig = DEFAULT_PHYSICS): Vec3[] {
  validateBodies(bodies);
  if (!(config.gravitationalConstant >= 0) || !Number.isFinite(config.gravitationalConstant)) throw new Error('G must be finite and non-negative');
  if (!(config.softening > 0) || !Number.isFinite(config.softening)) throw new Error('Softening must be positive and finite');
  return bodies.map((target, i) => {
    let total = vec3();
    for (let j = 0; j < bodies.length; j++) {
      if (i === j) continue;
      const source = bodies[j]!;
      const delta = sub(source.position, target.position);
      const r2 = delta.x ** 2 + delta.y ** 2 + delta.z ** 2 + config.softening ** 2;
      const invR3 = 1 / (r2 * Math.sqrt(r2));
      total = add(total, scale(delta, config.gravitationalConstant * source.mass * invR3));
    }
    return total;
  });
}

/** Velocity-Verlet integrator: second-order, time-reversible for smooth forces. */
export function stepVelocityVerlet(bodies: readonly Body[], dt: number, config: PhysicsConfig = DEFAULT_PHYSICS): Body[] {
  if (!(dt > 0) || !Number.isFinite(dt)) throw new Error('Time step must be positive and finite');
  const a0 = accelerations(bodies, config);
  const drifted = bodies.map((b, i) => ({
    ...b,
    position: add(add(b.position, scale(b.velocity, dt)), scale(a0[i]!, 0.5 * dt * dt)),
  }));
  const a1 = accelerations(drifted, config);
  return drifted.map((b, i) => ({
    ...b,
    velocity: add(bodies[i]!.velocity, scale(add(a0[i]!, a1[i]!), 0.5 * dt)),
  }));
}

export function totalMomentum(bodies: readonly Body[]): Vec3 {
  return bodies.reduce((p, b) => add(p, scale(b.velocity, b.mass)), vec3());
}
export function totalEnergy(bodies: readonly Body[], config: PhysicsConfig = DEFAULT_PHYSICS): number {
  validateBodies(bodies);
  let energy = 0;
  for (const b of bodies) energy += 0.5 * b.mass * (b.velocity.x ** 2 + b.velocity.y ** 2 + b.velocity.z ** 2);
  for (let i = 0; i < bodies.length; i++) for (let j = i + 1; j < bodies.length; j++) {
    const a = bodies[i]!, b = bodies[j]!;
    const r = Math.sqrt((a.position.x-b.position.x)**2 + (a.position.y-b.position.y)**2 + (a.position.z-b.position.z)**2 + config.softening**2);
    energy -= config.gravitationalConstant * a.mass * b.mass / r;
  }
  return energy;
}
export function snapshot(bodies: Body[], time: number, config: PhysicsConfig = DEFAULT_PHYSICS): SimulationSnapshot {
  return { time, bodies: bodies.map(b => ({ ...b })), totalEnergy: totalEnergy(bodies, config), totalMomentum: totalMomentum(bodies) };
}

export function createSolarToySystem(): Body[] {
  return [
    { id:'star', mass:1000, radius:1.05, position:vec3(0,0,0), velocity:vec3(0,0,0), color:'#ffd166' },
    { id:'planet-a', mass:1.2, radius:0.32, position:vec3(8,0,0), velocity:vec3(0,0,11.18), color:'#67e8f9' },
    { id:'planet-b', mass:0.35, radius:0.22, position:vec3(13,0,0), velocity:vec3(0,0,8.75), color:'#c4b5fd' },
    { id:'planet-c', mass:0.08, radius:0.15, position:vec3(-17,0,0), velocity:vec3(0,0,-7.67), color:'#fb7185' },
  ];
}
