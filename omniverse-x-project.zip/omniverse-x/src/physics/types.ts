import type { Vec3 } from '../math/vector3';
export interface Body { id: string; mass: number; radius: number; position: Vec3; velocity: Vec3; color: string; }
export interface PhysicsConfig { gravitationalConstant: number; softening: number; }
export interface SimulationSnapshot { time: number; bodies: Body[]; totalEnergy: number; totalMomentum: Vec3; }
