import { createSolarToySystem, snapshot, stepVelocityVerlet } from './nbody';
import type { Body, PhysicsConfig, SimulationSnapshot } from './types';
import { DEFAULT_PHYSICS } from './nbody';

export class NBodySimulation {
  private bodies: Body[];
  private elapsed = 0;
  private running = false;
  private config: PhysicsConfig;
  constructor(bodies: Body[] = createSolarToySystem(), config: PhysicsConfig = DEFAULT_PHYSICS) {
    this.bodies = bodies.map(b => ({ ...b })); this.config = { ...config };
  }
  play(): void { this.running = true; }
  pause(): void { this.running = false; }
  get isRunning(): boolean { return this.running; }
  setGravity(value: number): void {
    if (!(value >= 0) || !Number.isFinite(value)) throw new Error('Gravity must be finite and non-negative');
    this.config = { ...this.config, gravitationalConstant: value };
  }
  tick(dt: number): SimulationSnapshot {
    if (this.running) { this.bodies = stepVelocityVerlet(this.bodies, dt, this.config); this.elapsed += dt; }
    return snapshot(this.bodies, this.elapsed, this.config);
  }
  reset(): SimulationSnapshot { this.bodies = createSolarToySystem(); this.elapsed = 0; this.running = false; return snapshot(this.bodies, this.elapsed, this.config); }
  current(): SimulationSnapshot { return snapshot(this.bodies, this.elapsed, this.config); }
}
